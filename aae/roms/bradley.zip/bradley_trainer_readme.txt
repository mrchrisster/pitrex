BRADLEY TRAINER ROM PLACEMENT (Army Battlezone Prototype)
NOTE: THIS CODE WILL NOT RUN ON A STOCK BATTLEZONE BOARD!!!


Copyright 1980 by Atari. Program by Ed Rotberg
----------------------------------------------


Bradley Trainer
NAME		LOCATION	SIZE	CHECKSUM	NOTE
----------	--------	----	--------	----
bta3.bin	a3		2716	4a64
btb3.bin	b3		2716	bf02
btc1.bin	c1		2716	465b
btd1.bin	d1		2716	0b74
bte1.bin	e1		2716	e820
bth1.bin	h1		2716	a429
btj1.bin	j1		2716	947d
btk1.bin	k1		2716	82f3
btlm.bin	l/m		2716	3e98
btn1.bin	n1		2716	07a2


The following PROMs are from the mathbox. The same
PROMs were used in Battlezone, Red Baron, Vortex,
and Tempest.

NAME		LOCATION	SIZE	CHECKSUM
----------	--------	------	--------
136002.126	A1		74S288	08CD
136002.127	E1		74S287	04B4
136002.128	F1		74S287	04C2
136002.129	H1		74S287	01D5
136002.130	J1		74S287	0377
136002.131	K1		74S287	086E
136002.132	L1		74S287	05E7



-----------------------------------------------------
|                        END                        |
-----------------------------------------------------