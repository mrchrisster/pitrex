VECTOR BREAKOUT ROM PLACEMENT

Copyright 1999 by Clay Cowgil.
------------------------------


Vector Breakout
NAME		LOCATION	SIZE	CHECKSUM	NOTE
----------	--------	----	--------	----
vb_N3.bin	N/P3		2716	6B4C
vb_R3.bin	R3		2716	2D05

vb_D1.bin	D1		2716	6DE0
vb_E1.bin	E1		2716	89E4
vb_F1.bin	F1		2716	DB78
vb_H1.bin	H1		2716	783B

vb_R1.bin	R1		2716	F3C2



The following PROMs are from the mathbox. The same
PROMs were used in Battlezone, Red Baron, Vortex,
and Tempest.

NAME		LOCATION	SIZE	CHECKSUM
----------	--------	------	--------
136002.126	A1		74S288	08CD
136002.127	E1		74S287	04B4
136002.128	F1		74S287	04C2
136002.129	H1		74S287	01D5
136002.130	J1		74S287	0377
136002.131	K1		74S287	086E
136002.132	L1		74S287	05E7



Clearing the highscore in V-Breakout.
From the Multigame menu, select V-Breakout with the spinner
(V-Breakout is highlighted in the menu). Hold down the P2
Start Button. Then press and hold the Fire button. Once
V-Breakout starts the highscore should be cleared to "0000".

Easter Eggs.
First one: Vector Breakout Plus. What you do is: from the main multigame 
menu select V-Breakout with the spinner. Then, press and hold-down the P1 
Start Button ('er, or maybe the P2 Start Button... Check the manual-- one 
will be documented to clear the high scores. Do the "other". ;-) and then 
press Fire to start the game. If you held down the correct button you 
should now see "Vector Breakout Plus" which will look obviously a bit 
different. I'll let you play it and see what's different. 

Second one: Level Skip. With Vector Breakout Plus running, press and hold 
Fire and SuperZapper, then tap the P2 Start button. You'll be able to 
select any of the levels from Vector Breakout Plus. 


-----------------------------------------------------
|                        END                        |
-----------------------------------------------------