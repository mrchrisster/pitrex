Sundance ROM Placement

Copyright 1979 Cinematronics. Program by Tim Skelly.


NAME		LOCATION	SIZE	CHECKSUM
---------	--------	----	--------
Sundance.p7	P7 (LO)		2716	C0B4
Sundance.r7	R7 (UO)		2716	4A1B
Sundance.t7	T7 (LE)		2716	C63F
Sundance.u7	U7 (UE)		2716	2C7D