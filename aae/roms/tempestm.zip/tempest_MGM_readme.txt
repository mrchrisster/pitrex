TEMPEST MULTIGAME MENU ROM PLACEMENT

Program by Clay Cowgil.
-----------------------


Tempest Multigame Menu
NAME		LOCATION	SIZE	CHECKSUM	NOTE
----------	--------	----	--------	----
menu_n3.bin	N3		2716	6B4C
menu_r3.bin	R3		2716	2D05

menu_d1.bin	D1		2716	A8C6
menu_e1.bin	E1		2716	40C1
menu_f1.bin	F1		2716	3907
menu_r1.bin	R1		2716	F3BE



The following PROMs are from the mathbox. The same
PROMs were used in Battlezone, Red Baron, Vortex,
and Tempest.

NAME		LOCATION	SIZE	CHECKSUM
----------	--------	------	--------
136002.126	A1		74S288	08CD
136002.127	E1		74S287	04B4
136002.128	F1		74S287	04C2
136002.129	H1		74S287	01D5
136002.130	J1		74S287	0377
136002.131	K1		74S287	086E
136002.132	L1		74S287	05E7

-----------------------------------------------------
|                        END                        |
-----------------------------------------------------