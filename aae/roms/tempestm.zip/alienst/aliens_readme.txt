ALIENS ROM PLACEMENT (early Tempest Prototype)

Copyright 1981 by Atari. Program by Dave Theurer.
-------------------------------------------------


Aliens
NAME		LOCATION	SIZE	CHECKSUM	NOTE
----------	--------	----	--------	----
Aliens_N3.bin	N/P3		2716	3C0C
Aliens_R3.bin	R3		2716	75F9

Aliens_D1.bin	D1		2716	5518
Aliens_E1.bin	E1		2716	5518
Aliens_F1.bin	F1		2716	A85C
Aliens_H1.bin	H1		2716	34CB
Aliens_J1.bin	J1		2716	656A
Aliens_K1.bin	K1		2716	E6E9
Aliens_L1.bin	L/M1		2716	EAF2
Aliens_N1.bin	M/N1		2716	F84E

Aliens_P1.bin	P1		2716	E431
Aliens_R1.bin	R1		2716	5D6A
Aliens_R1A.bin	R1		2716	5D5A		Alternate versrion



The following PROMs are from the mathbox. The same
PROMs were used in Battlezone, Red Baron, Vortex,
and Tempest.

NAME		LOCATION	SIZE	CHECKSUM
----------	--------	------	--------
136002.126	A1		74S288	08CD
136002.127	E1		74S287	04B4
136002.128	F1		74S287	04C2
136002.129	H1		74S287	01D5
136002.130	J1		74S287	0377
136002.131	K1		74S287	086E
136002.132	L1		74S287	05E7



Use the following DIP switch settings for Aliens:

Switch   1   2   3   4   5   6   7   8
--------------------------------------
K10/11  off off off off  -   -   -   -
L12     on  on  on  on  off on  on  on
N13     on  off off on  on  on  on  on



To run Aliens, you must disable the watchdog.

-----------------------------------------------------
|                        END                        |
-----------------------------------------------------