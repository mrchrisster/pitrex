Star Hawk ROM Placement

Copyright 1981 Cinematronics. Program by Tim Skelly.


NAME		LOCATION	SIZE	CHECKSUM
---------	--------	----	--------
Starhawk.r7	R7 (UO)		2716	8C7F
Starhawk.u7	U7 (UE)		2716	CBE2