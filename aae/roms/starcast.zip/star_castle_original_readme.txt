Star Castle (original version) ROM Placement

Copyright 1980 Cinematronics. Program by Tim Skelly and Scott Boden.


NAME		LOCATION	SIZE	CHECKSUM
---------	--------	----	--------
Starcas.p7	P7 (LO)		2716	F6FE
Starcas.p7	R7 (UO)		2716	3C25
Starcas.p7	T7 (LE)		2716	E8C6
Starcas.p7	U7 (UE)		2716	3C74