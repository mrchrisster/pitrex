Subject: VECTOR: Stupid Battlezone tricks...
Date: Mon, 09 Oct 2000 13:53:53 PDT
From: "Clay Cowgill" <vector_clay@hotmail.com>
To: vectorlist@synthcom.com

Hey everyone,

Since I've been monkeying around getting a Battlezone upright working (which
has finally been running for a few days now without incident, BTW) I ended
up dinking around with the code too.

(Actually, I decided that this was a perfect time to finish the BZ
high-score-saver board instead of the three-dozen other projects I'm working
on.  I'm easily distr-- hey, look! this CD is really *sparkly*... Uhhhh...
Now what did you want? ;-)

The high-score-saver is also kind-of a mini-multigame platform, so I thought
it would be cool to add some little bells and whistles.  I converted all the
dip-switch settings to load from backup-ram, so those are now "settable"
from an on-screen menu.  (Yeah, BFD, I know...)  You can also set it to boot
to either Battlezone, the menu or...

Battlezone Plus!  (Or FHMC Battlezone, or some other name I haven't decided
yet...)

To make a long story short, without having to re-write *too* much code, I
made a faster/meaner version of Battlezone.  Your tank turns faster (about
half again as fast while turning or almost twice as fast in "rotate" mode),
you can shoot twice as fast (initially), you can go forwards about three
times as fast (but reverse at the same "old" speed).  Enemy tanks shoot at
the "normal" rate initially (you get two shots to their one though) but as
your score goes up, the shells get *faster*, so the enemy tanks can really
cook 'em off at you (and vice-versa).

Any suggestions for other stuff I should look into?  I really don't want to
get too far into the game "engine" (I don't want to make it too big of a
project), but there might be something relatively easy to do that makes it
interesting.  The changes I made are configurable from the backup-sram so
the menu system can actually modify the details (like speed of turns, rate
of fire, ratio of player to enemy fire rate, etc).

A couple things I might be able to do would be:

1) A limited number of "super-shells".  Basically you'd have to reach down
and hold the start button, then press fire-- but, your shell would travel at
death-ray like speed. ;-)  Interesting compromise from having to let go of
the steering for a bit...

or

2) Hyperspace.  Maybe just get three per game?  Pressing start teleports you
to a new random location.  I don't know how hard it'd be to work around
playfield objects, or what some game elements (like the Missile) would do.
Could be bad.

or

3) Warp.  Pressing start slows enemy shots (and maybe tanks/missiles) to
like 1/4 speed for a couple seconds?

Anyway, suggestions welcome.  The hardware right now is a no-solder
install-- remove CPU, plug in daughtercard, plug in CPU to daughtercard.
You can remove the program EPROMs and program SRAMs if you want to save some
power.  It'll probably fix a lot of reliability problems too as an added
bonus.  If I end up adding Battlezone+ as another bank of memory it will
probably require one wire down to the main board (to pick up the 6MHz
clock).  I might be able to put in BZ+ just as patches since I opened up a
lot more memory, but I want to be sure not to mess with how the "real" BZ
plays in the process.

-Clay

--------------------------------------------

NAME		LOCATION	SIZE	CHECKSUM	NOTE
----------	--------	----	--------	----
036408.01.bin	?		2716			
036409.01.bin	N1		2716			
036410.01.bin	L/M1		2716			original
036411.01.bin	K1		2716			original
036412.01.bin	J1		2716			
036413.01.bin	F/H1		2716			original
036414.01.bin	E1		2716			
036421.01.bin	A3		2716			original
036422.01.bin	B/C3		2716			

