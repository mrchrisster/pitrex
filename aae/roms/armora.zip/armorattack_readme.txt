Armor Attack ROM Placement

Copyright 1980 Cinematronics. Program by Tim Skelly.


NAME		LOCATION	SIZE	CHECKSUM
---------	--------	----	--------
Armor.p7	P7 (LO)		2732	6C4E
Armor.r7	R7 (UO)		2732	96F5
Armor.t7	T7 (LE)		2732	60FF
Armor.u7	U7 (UE)		2732	F02D