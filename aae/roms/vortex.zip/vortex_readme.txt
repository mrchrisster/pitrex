VORTEX (prototype) ROM PLACEMENT

Copyright 1981 by Atari. Program by Dave Theurer.
Game code runs on a stock Tempest PCB.


NAME		LOCATION	SIZE	CHECKSUM
--------------	---------------	------	--------
136002.111	N/P3		2716	5CED
136002.112	R3		2716	13C3

136002.113	D1		2716	6617
136002.114	E1		2716	176F
136002.115	F1		2716	E352
136002.116	H1		2716	FC19
136002.117	J1		2716	2478
136002.118	K1		2716	EEEB
136002.119	L/M1		2716	7431
136002.120	M/N1		2716	BFA2
136002.121	P1		2716	61E3
136002.122	R1		2716	980C
R1_alt		R1		2716	8790



The following PROMs are from the mathbox. The same
PROMs were used in Battlezone, Red Baron, Vortex,
and Tempest.

NAME		LOCATION	SIZE	CHECKSUM
----------	--------	------	--------
136002.126	A1		74S288	08CD
136002.127	E1		74S287	04B4
136002.128	F1		74S287	04C2
136002.129	H1		74S287	01D5
136002.130	J1		74S287	0377
136002.131	K1		74S287	086E
136002.132	L1		74S287	05E7



Use the following DIP switch settings for Vortex:

Switch   1   2   3   4   5   6   7   8
--------------------------------------
K10/11  off off off off  -   -   -   -
L12     on  on  on  on  off on  on  on
N13     on  off off on  on  on  on  on



-----------------------------------------------------
|                        END                        |
-----------------------------------------------------