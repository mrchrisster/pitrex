Warrior ROM Placement

Copyright 1978 Vectorbeam. Program by Tim Skelly.


NAME		LOCATION	SIZE	CHECKSUM
---------	--------	----	--------
warrior.p7	P7 (LO)		2716	940D
warrior.r7	R7 (UO)		2716	F834
warrior.t7	T7 (LE)		2716	BB9B
warrior.u7	U7 (UE)		2716	FE81